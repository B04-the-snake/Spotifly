﻿using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators.OAuth2;
using Spotifly.MVVM.Model;
using System;
using System.Collections.ObjectModel;


/*
   WYJAŚNIENIE KODU
 * Ten kod definiuje klasę języka C# o nazwie „MainViewModel”. 
 * Klasa ma właściwość „Songs” typu „ObservableCollection<Item>”. 
 * W konstruktorze klasy tworzona jest instancja „ObservableCollection” i przypisywana do właściwości „Songs”.
 * Konstruktor wywołuje również metodę „PopulateCollection”, aby wypełnić kolekcję danymi. 
 * Metoda „PopulateCollection” tworzy instancję klasy „RestClient” i używa jej do wysyłania żądania API do punktu końcowego „nowych wydań” Spotify.
 * Metoda używa autoryzacji OAuth2, a token okaziciela jest dodawany do żądania jako nagłówek "Authorization".  
 * Po wysłaniu żądania metoda deserializuje odpowiedź JSON do obiektu typu „TrackModel”.
 * Następnie metoda wykonuje iterację elementów w kolekcji „data.Albums.Items”, 
   ustawia właściwość „Duration”, której przypisywany jest losowy czas utworu „Random duration” i dodaje każdy element do kolekcji „Songs”.
*/


namespace Spotifly.MVVM.ViewModel
{
    internal class MainViewModel
    {
        public ObservableCollection<Item> Songs { get; set; }
        public MainViewModel()
        {
            Songs = new ObservableCollection<Item>();
            PopulateCollection();
        }

        void PopulateCollection()
        {
            var client = new RestClient();
            client.Authenticator = new OAuth2AuthorizationRequestHeaderAuthenticator("BQBFN-hHecxtAHhe_nBhe96OZtrk2MXnoh6wuD1C76oWNl_4EkohM06Kz12EefVZyQbWAYhn5MTRAqJChuqUag6RWh4Pf89kbtMuynpNtHh08p5S7OrOfFoEGtt6YZZMM6cUsHLxNz77HPOVvbMtAudfBB8AePKo_pmd9Vzch240GaLDlvGH3uEzfznS44jm6S5A", "Bearer");

            var request = new RestRequest("https://api.spotify.com/v1/browse/new-releases", Method.Get);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");

            var response = client.GetAsync(request).GetAwaiter().GetResult();
            var data = JsonConvert.DeserializeObject<TrackModel>(response.Content);

            Random random = new Random();
            int minutes = random.Next(2, 5);
            int seconds = random.Next(0, 60);
            string duration = string.Format("{0:00}:{1:00}", minutes, seconds);

            for (int i = 0; i < data.Albums.Limit; i++)
            {
                var track = data.Albums.Items[i];
                track.Duration = duration;
                Songs.Add(track);
            }
        }
    }
}


